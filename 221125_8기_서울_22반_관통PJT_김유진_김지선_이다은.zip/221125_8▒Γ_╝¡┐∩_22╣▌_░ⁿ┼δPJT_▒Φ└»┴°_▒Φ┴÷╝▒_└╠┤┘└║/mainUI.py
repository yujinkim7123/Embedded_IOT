# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainUI.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide2.QtWidgets import (QApplication, QLabel, QMainWindow, QPushButton,
    QSizePolicy, QStatusBar, QTextBrowser, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(694, 525)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.go = QPushButton(self.centralwidget)
        self.go.setObjectName(u"go")
        self.go.setGeometry(QRect(140, 270, 91, 71))
        self.right = QPushButton(self.centralwidget)
        self.right.setObjectName(u"right")
        self.right.setGeometry(QRect(240, 350, 91, 71))
        self.left = QPushButton(self.centralwidget)
        self.left.setObjectName(u"left")
        self.left.setGeometry(QRect(40, 350, 91, 71))
        self.mid = QPushButton(self.centralwidget)
        self.mid.setObjectName(u"mid")
        self.mid.setGeometry(QRect(140, 350, 91, 71))
        self.back = QPushButton(self.centralwidget)
        self.back.setObjectName(u"back")
        self.back.setGeometry(QRect(140, 430, 91, 71))
        self.text = QTextBrowser(self.centralwidget)
        self.text.setObjectName(u"text")
        self.text.setGeometry(QRect(40, 20, 271, 231))
        self.start = QPushButton(self.centralwidget)
        self.start.setObjectName(u"start")
        self.start.setGeometry(QRect(570, 360, 91, 71))
        self.stop = QPushButton(self.centralwidget)
        self.stop.setObjectName(u"stop")
        self.stop.setGeometry(QRect(470, 360, 91, 71))
        self.image = QLabel(self.centralwidget)
        self.image.setObjectName(u"image")
        self.image.setGeometry(QRect(380, 30, 231, 211))
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.go.clicked.connect(MainWindow.go)
        self.left.clicked.connect(MainWindow.left)
        self.right.clicked.connect(MainWindow.right)
        self.mid.clicked.connect(MainWindow.mid)
        self.back.clicked.connect(MainWindow.back)
        self.stop.clicked.connect(MainWindow.stop)
        self.start.clicked.connect(MainWindow.start)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.go.setText(QCoreApplication.translate("MainWindow", u"GO", None))
        self.right.setText(QCoreApplication.translate("MainWindow", u"RIGHT", None))
        self.left.setText(QCoreApplication.translate("MainWindow", u"LEFT", None))
        self.mid.setText(QCoreApplication.translate("MainWindow", u"CENTER", None))
        self.back.setText(QCoreApplication.translate("MainWindow", u"BACK", None))
        self.start.setText(QCoreApplication.translate("MainWindow", u"START", None))
        self.stop.setText(QCoreApplication.translate("MainWindow", u"STOP", None))
        self.image.setText(QCoreApplication.translate("MainWindow", u"asdfasdf", None))
    # retranslateUi

