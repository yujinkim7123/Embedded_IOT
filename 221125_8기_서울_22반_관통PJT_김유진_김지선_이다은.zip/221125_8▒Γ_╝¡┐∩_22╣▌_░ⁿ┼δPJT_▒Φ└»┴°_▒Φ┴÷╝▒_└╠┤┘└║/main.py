from PySide2.QtWidgets import *
from PySide2.QtCore import *
from mainUI import Ui_MainWindow
from time import *
from PySide2.QtGui import QPixmap
from gpiozero import DistanceSensor, LED, TonalBuzzer
from gpiozero.tones import Tone
from time import sleep
from Raspi_MotorHAT import Raspi_MotorHAT, Raspi_DCMotor
from picamera import PiCamera
camera=PiCamera()

sensor = DistanceSensor(24,23) #echo, trigger
green = LED(19)
red = LED(26)
flag = 0
b=TonalBuzzer(17)


lst = [261.62, 329.62, 391.99, 523.25] #buzzer
lst1 = [352.34, 352.34, 352.34]

mh = Raspi_MotorHAT(addr = 0x6f)
motor = mh.getMotor(2) # M2단자에 모터연결
speed = 125 # 모터 속도 0~255
motor.setSpeed(speed)

# 서보 초기설정
servo = mh._pwm
servo.setPWMFreq(50)

servoCH = 0 # 서보 연결된 핀
SERVO_PULSE_MAX = 400   # 서보 작동 범위
SERVO_PULSE_MIN = 200

class MyThread(QThread):

    mySignal = Signal(int)

    def __init__(self):
        super().__init__()
        
    def run(self):
        while True:
            dis = sensor.distance
    
            if dis < 0.4 and flag == 0:
                motor.run(Raspi_MotorHAT.RELEASE)
                sleep(0.5)
                camera.rotation=270
                camera.capture('/home/pi/capture.jpg')
                self.mySignal.emit(1)
                print("capture")
                for i in range(4):
                    b.play(lst[i])
                    sleep(0.2)
                b.stop()
            print(dis)

class MyApp(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.init()
        self.angle = 0
        self.th = MyThread()
        self.th.mySignal.connect(self.settingUI)
        self.th.start()

  
    def settingUI(self, val):
        self.ui.image.setPixmap(QPixmap(r"/home/pi/capture.jpg"))
        self.ui.image.setScaledContents(True)


    def init(self):
        self.timer = QTimer()

    def start(self):
        self.timer.start()

    def insertCommand(self, cmd_string, arg_string):

        time = QDateTime().currentDateTime().toPython()
        is_finish = 0
        str = "%s | %6s | %6s | %4d" % (time.strftime("%Y%m%d %H:%M:%S"), cmd_string, arg_string, is_finish)
        self.ui.text.append(str)

    def steer(self):
        if self.angle <= -60:
            self.angle = -60
        if self.angle >= 60:
            self.angle = 60
        pulse_time = SERVO_PULSE_MIN + (SERVO_PULSE_MAX - SERVO_PULSE_MIN) // 180 * (self.angle + 90)  # angle = -90˚~ +90˚ 사이의 값. 비례해서 pulse_time이 정해짐
        servo.setPWM(servoCH, 0, pulse_time)

    def go(self):
        self.insertCommand("go", "0")
        motor.run(Raspi_MotorHAT.BACKWARD)

    def stop(self):
        self.insertCommand("stop", "0")
        motor.run(Raspi_MotorHAT.RELEASE)

    def back(self):
        self.insertCommand("back", "0")
        motor.run(Raspi_MotorHAT.FORWARD)

    def left(self):
        self.insertCommand("left", "0")
        self.angle = -50
        self.steer()

    def mid(self):
        self.insertCommand("mid", "0")
        self.angle = 0
        self.steer()

    def right(self):
        self.insertCommand("right", "0")
        self.angle = 50
        self.steer()

app = QApplication()

win = MyApp()
win.show()
app.exec_()